import {SelectCellEditor} from "./selectCellEditor";

export class PopupSelectCellEditor extends SelectCellEditor {

    public isPopup(): boolean {
        return true;
    }

}
